1.  `python_configure.bzl`: Configuration files for Python interoperability
    development libraries required for building with Cython. Copied from [gRPC
    Core](https://github.com/grpc/grpc/tree/master/third_party/py).

2.  `cython_library.bzl`: Cython support for Bazel. Copied from
    [gRPC Core](https://github.com/grpc/grpc/blob/master/bazel/cython_library.bzl).
