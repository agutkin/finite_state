Pynini is a Python extension module which allows the user to compile, optimize,
and apply grammar rules. Rules can be compiled into weighted finite state
transducers, pushdown transducers, or multi-pushdown transducers. For general
information and a detailed tutorial, see
[pynini.opengrm.org](http://pynini.opengrm.org).

Pynini is primarily developed by [Kyle Gorman](mailto:kbg@google.com) with the
help of contributors. If you use Pynini in your research, we would appreciate if
you cite the following paper:

> K. Gorman. 2016.
> [Pynini: A Python library for weighted finite-state grammar compilation](http://openfst.cs.nyu.edu/twiki/pub/GRM/Pynini/pynini-paper.pdf).
> In *Proc. ACL Workshop on Statistical NLP and Weighted Automata*, 75-80.

(Note that some of the code samples in the paper are now out of date and not
expected to work.)

There are various ways to install Pynini for your platform.

## Windows

While Pynini is neither designed for nor tested on Windows, it can be installed
using the
[Windows Subsystem for Linux](https://docs.microsoft.com/en-us/windows/wsl/install-win10)
(WSL). Simply enter the WSL environment and follow the Linux instructions below.

## MacOS

A pre-compiled Pynini can be installed from
[`conda-forge`](https://conda-forge.org/). Issue:

```
conda install -c conda-forge pynini
```

Alternatively, one can install Pynini from source from [PyPI](https://pypi.org/)
if one has:

-   A standards-compliant C++17 compiler (GCC \>= 7 or Clang \>= 700)
-   The compatible recent version of [OpenFst](http://openfst.org) (see
    [`NEWS`](NEWS) for this) built with the `far`, `pdt`, `mpdt`, and `script`
    extensions (i.e., built with `./configure --enable-grm`) and headers
-   [Python 3.6+](https://www.python.org) and headers

Issue:

```
pip install pynini
```

## Linux

A pre-compiled Pynini can be installed from
[`conda-forge`](https://conda-forge.org/). Issue:

```
conda install -c conda-forge pynini
```

A pre-compiled [`manylinux`](https://github.com/pypa/manylinux) wheel can also
be installed from [PyPI](https://pypi.org/) on x86-64. Unlike the `conda-forge`
option above, which also installs [OpenFst](http://openfst.org/) and
[Graphviz](https://graphviz.org/), this does not install the OpenFst or Graphviz
command-line tools. Alternatively, one can install Pynini from source from
[PyPI](https://pypi.org/) if one has:

-   A standards-compliant C++17 compiler (GCC \>= 7 or Clang \>= 700)
-   The compatible recent version of [OpenFst](http://openfst.org) (see
    [`NEWS`](NEWS) for this) built with the `far`, `pdt`, `mpdt`, and `script`
    extensions (i.e., built with `./configure --enable-grm`) and headers
-   [Python 3.6+](https://www.python.org) and headers

Issue:

```
pip install pynini
```

This will install the pre-compiled `manylinux` wheel (if available for the
release and compatible with your platform), and build and install from source if
not.

## Testing

To confirm successful installation, run `python test/pynini_test.py` from this
directory; if all tests pass, the final line will read `OK`.

# Python version support

Pynini 2.0.0 and onward support Python 3. Pynini 2.1 versions (onward) drop
Python 2 support.

# License

Pynini is released under the Apache license. See `LICENSE` for more information.

# Interested in contributing?

See `CONTRIBUTING` for more information.

# Mandatory disclaimer

This is not an official Google product.
