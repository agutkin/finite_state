#!/bin/bash
# Simple LM over the Earnest dataset.

# Usage:
#
# blaze build -c opt nlp/grm/language/pynini/examples:make_chatspeak_lm 
# blaze-bin/nlp/grm/language/pynini/examples/make_chatspeak_lm /var/tmp/earnest.lm

source gbash.sh || exit

DEFINE_string method "witten_bell" "Smoothing method"
DEFINE_int order "3" "N-gram order"

gbash::init_google "$@"

set -e -u

readonly FAR_PREFIX="${RUNFILES}/google3/nlp/fst/extensions/far"
readonly NGRAM_PREFIX="${RUNFILES}/google3/nlp/fst_grammar/ngram"
readonly TMPDIR=$(mktemp -d --tmpdir $$.XXXXX)

readonly INPUT="${NGRAM_PREFIX}/testdata/earnest.txt"
readonly LINPUT="${TMPDIR}/earnest.txt"
readonly SYMS="${TMPDIR}/syms"
readonly FAR="${TMPDIR}/far"
readonly COUNTS="${TMPDIR}/counts"

readonly OUTPUT="${GBASH_ARGV[0]}"

LOG INFO "TMPDIR=${TMPDIR}"

LOG INFO "Lower-casing corpus"
tr 'A-Z' 'a-z' <"${INPUT}" >"${LINPUT}"

LOG INFO "Creating FAR symbols"
"${NGRAM_PREFIX}/ngramsymbols" \
  "${LINPUT}" "${SYMS}"

LOG INFO "Creating FAR"
"${FAR_PREFIX}/farcompilestrings" \
  "--fst_type=compact" \
  "--symbols=${SYMS}" \
  "--keep_symbols" \
  "${LINPUT}" \
  "${FAR}"

LOG INFO "Collecting counts"
"${NGRAM_PREFIX}/ngramcount" \
    --norequire_symbols \
    --order="${FLAGS_order}" \
    "${FAR}" "${COUNTS}"

readonly FST="${TMPDIR}/fst"
LOG INFO "Normalizing model"
"${NGRAM_PREFIX}/ngrammake" \
    --method="${FLAGS_method}" \
    "${COUNTS}" "${FST}"

# Prints out some info about the model.
echo "N-Gram model info:"
echo
"${NGRAM_PREFIX}/ngraminfo" "${FST}"
echo

mv "${FST}" "${OUTPUT}"
rm -r "${TMPDIR}"

LOG INFO "Output FST: ${OUTPUT}"
