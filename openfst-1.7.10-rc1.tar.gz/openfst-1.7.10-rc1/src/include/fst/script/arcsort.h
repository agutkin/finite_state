// See www.openfst.org for extensive documentation on this weighted
// finite-state transducer library.

#ifndef FST_SCRIPT_ARCSORT_H_
#define FST_SCRIPT_ARCSORT_H_

#include <utility>

#include <fst/types.h>
#include <fst/arcsort.h>
#include <fst/script/fst-class.h>

namespace fst {
namespace script {

enum class ArcSortType : uint8 { ILABEL, OLABEL };

using ArcSortArgs = std::pair<MutableFstClass *, ArcSortType>;

template <class Arc>
void ArcSort(ArcSortArgs *args) {
  MutableFst<Arc> *fst = std::get<0>(*args)->GetMutableFst<Arc>();
  switch (std::get<1>(*args)) {
    case ArcSortType::ILABEL: {
      const ILabelCompare<Arc> icomp;
      ArcSort(fst, icomp);
      return;
    }
    case ArcSortType::OLABEL: {
      const OLabelCompare<Arc> ocomp;
      ArcSort(fst, ocomp);
      return;
    }
  }
}

void ArcSort(MutableFstClass *ofst, ArcSortType);

}  // namespace script
}  // namespace fst

#endif  // FST_SCRIPT_ARCSORT_H_
