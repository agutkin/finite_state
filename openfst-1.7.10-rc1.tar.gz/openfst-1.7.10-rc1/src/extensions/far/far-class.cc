// See www.openfst.org for extensive documentation on this weighted
// finite-state transducer library.

#include <fst/extensions/far/far-class.h>

#include <fst/extensions/far/script-impl.h>
#include <fst/script/script-impl.h>

namespace fst {
namespace script {

// FarReaderClass.

std::unique_ptr<FarReaderClass> FarReaderClass::Open(
    const std::string &source) {
  const std::vector<std::string> sources{source};
  return FarReaderClass::Open(sources);
}

std::unique_ptr<FarReaderClass> FarReaderClass::Open(
    const std::vector<std::string> &sources) {
  if (sources.empty()) {
    LOG(ERROR) << "FarReaderClass::Open: No files specified";
    return nullptr;
  }
  auto arc_type = LoadArcTypeFromFar(sources.front());
  // An empty arc type may result from the FAR not existing, or an empty FAR.
  // If it doesn't exist, OpenFarReaderClass will return null below.
  // If it's an empty FAR, set the type to standard, so empty FARs can be read.
  // TODO(jrosenstock): It would be better to add and use TrivialWeight or
  // EmptyWeight (if that's allowed).  At that point, pushing the empty
  // handling down into LoadArcTypeFromFar seems reasonable.
  if (arc_type.empty()) arc_type = "standard";
  OpenFarReaderClassArgs args(sources);
  args.retval = nullptr;
  Apply<Operation<OpenFarReaderClassArgs>>("OpenFarReaderClass", arc_type,
                                           &args);
  return std::move(args.retval);
}

REGISTER_FST_OPERATION(OpenFarReaderClass, StdArc, OpenFarReaderClassArgs);
REGISTER_FST_OPERATION(OpenFarReaderClass, LogArc, OpenFarReaderClassArgs);
REGISTER_FST_OPERATION(OpenFarReaderClass, Log64Arc, OpenFarReaderClassArgs);

// FarWriterClass.

std::unique_ptr<FarWriterClass> FarWriterClass::Create(
    const std::string &source, const std::string &arc_type, FarType type) {
  CreateFarWriterClassInnerArgs iargs(source, type);
  CreateFarWriterClassArgs args(iargs);
  args.retval = nullptr;
  Apply<Operation<CreateFarWriterClassArgs>>("CreateFarWriterClass", arc_type,
                                             &args);
  return std::move(args.retval);
}

REGISTER_FST_OPERATION(CreateFarWriterClass, StdArc, CreateFarWriterClassArgs);
REGISTER_FST_OPERATION(CreateFarWriterClass, LogArc, CreateFarWriterClassArgs);
REGISTER_FST_OPERATION(CreateFarWriterClass, Log64Arc,
                       CreateFarWriterClassArgs);

}  // namespace script
}  // namespace fst
