// See www.openfst.org for extensive documentation on this weighted
// finite-state transducer library.

#include <fst/extensions/pdt/getters.h>

namespace fst {
namespace script {

bool GetPdtComposeFilter(const std::string &str, PdtComposeFilter *cf) {
  if (str == "expand") {
    *cf = PdtComposeFilter::EXPAND;
  } else if (str == "expand_paren") {
    *cf = PdtComposeFilter::EXPAND_PAREN;
  } else if (str == "paren") {
    *cf = PdtComposeFilter::PAREN;
  } else {
    return false;
  }
  return true;
}

bool GetPdtParserType(const std::string &str, PdtParserType *pt) {
  if (str == "left") {
    *pt = PdtParserType::LEFT;
  } else if (str == "left_sr") {
    *pt = PdtParserType::LEFT_SR;
  } else {
    return false;
  }
  return true;
}

}  // namespace script
}  // namespace fst
