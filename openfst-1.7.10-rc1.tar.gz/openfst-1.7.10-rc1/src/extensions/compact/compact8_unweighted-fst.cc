// See www.openfst.org for extensive documentation on this weighted
// finite-state transducer library.

#include <fst/compact-fst.h>
#include <fst/fst.h>

namespace fst {

static FstRegisterer<CompactUnweightedFst<StdArc, uint8>>
    CompactUnweightedFst_StdArc_uint8_registerer;

static FstRegisterer<CompactUnweightedFst<LogArc, uint8>>
    CompactUnweightedFst_LogArc_uint8_registerer;

static FstRegisterer<CompactUnweightedFst<Log64Arc, uint8>>
    CompactUnweightedFst_Log64Arc_uint8_registerer;

}  // namespace fst
