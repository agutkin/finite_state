# Lint as: python3
# For general information on the Pynini grammar compilation library, see
# pynini.opengrm.org.
"""Combination of Chatspeak model with LM."""

from typing import List

import pynini
from pynini.examples import chatspeak


# TODO(rws): The chatspeak lexicon is ill matched to the tokenizations used in
# the Earnest data, since things like "don't" appear in the latter as "don
# t". Need to add some way to deal with that. Or we could leave it as an
# exercise for the reader (basically they'd just need to add in an FST that maps
# the "'" to space).
class ChatspeakModel:
  """Combination of the Chatspeak model with an LM."""

  def __init__(self, chat_lexicon_path: str, lm_path: str) -> None:
    self._deduplicator = chatspeak.Deduplicator()
    self._chat_lexicon = chatspeak.Lexicon(chat_lexicon_path)
    self._lm = pynini.Fst.read(lm_path)
    self._lm_syms = self._lm.input_symbols()
    self._lm_lexicon = [w for (l, w) in self._lm_syms if l > 0]
    self._lm_lexicon_fsa = pynini.union(*self._lm_lexicon)
    self._deabbreviator = chatspeak.Deabbreviator(self._lm_lexicon_fsa)
    lm_mapper = pynini.string_map(
        self._lm_lexicon,
        input_token_type="byte",
        output_token_type=self._lm_syms)
    self._bytes_to_lm_mapper = (
        lm_mapper + (pynini.cross(" ", "") + lm_mapper).closure()).optimize()
    self._lm_to_bytes_mapper = pynini.invert(self._bytes_to_lm_mapper)

  def tokenize(self, sentence: str) -> List[str]:
    return sentence.split()

  def decode(self, sentence: str) -> str:
    """Decodes sentence with the Chatspeak model + LM.

    Args:
      sentence: an input sentence.

    Returns:
      String representing the normalized sentence.
    """
    sentence_fst = pynini.accep("")
    internal = False
    for token in self.tokenize(sentence):
      token_fst = self._deduplicator.deduplicate(token, self._lm_lexicon_fsa)
      token_fst |= self._chat_lexicon.expand(token)
      token_fst |= token @ chatspeak.SPECIAL_REGEXPS
      token_fst |= self._deabbreviator.expand(token)
      token_fst.optimize()
      if internal:
        sentence_fst += " "
      sentence_fst += token_fst
      internal = True
    sentence_fst.optimize()
    expanded = pynini.shortestpath(
        sentence_fst @ self._bytes_to_lm_mapper @ self._lm
        @ self._lm_to_bytes_mapper)
    return expanded.string()

