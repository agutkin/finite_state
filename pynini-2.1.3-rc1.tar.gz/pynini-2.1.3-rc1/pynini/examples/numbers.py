# Lint as: python3
# For general information on the Pynini grammar compilation library, see
# pynini.opengrm.org.
"""Simple number name grammar for (American) English.

Names all numbers from 1 to 9999999.
"""

import string

import pynini


def insert(term: pynini.FstLike) -> pynini.Fst:
  """Helper function to produce a transducer that inserts term.

  Args:
    term: a string or acceptor.

  Returns:
    A transducer that inserts term.
  """
  return pynini.cross("", term)


def delete(term: pynini.FstLike) -> pynini.Fst:
  """Helper function to produce a transducer that deletes term.

  Args:
    term: a string or acceptor.

  Returns:
    A transducer that deletes term.
  """
  return pynini.cross(term, "")


D = pynini.union(*string.digits)

# Powers of ten that have single-word representations in English. E1*
# is a special symbol we will use in the teens below.
POWERS = pynini.union("[E1]", "[E1*]", "[E2]", "[E3]", "[E6]")

SIGSTAR = pynini.union(D, POWERS).closure().optimize()

# Inserts factors in the appropriate place in the digit sequence.
RAW_FACTORIZER = (
    D + insert("[E6]") + D + insert("[E2]") + D + insert("[E1]") + D +
    insert("[E3]") + D + insert("[E2]") + D + insert("[E1]") + D)

# Deletes "0" and "0" followed by a factor, so as to clear out unverbalized
# material in cases like "2,000,324". This needs to be done with some care since
# we need to keep E3 if it has a multiplier, but not if there is nothing between
# the thousands and the millions place.
DEL_ZEROS = (pynini.cdrewrite(delete("0"), "", "[EOS]", SIGSTAR)
             @ pynini.cdrewrite(delete("0[E1]"), "", "", SIGSTAR)
             @ pynini.cdrewrite(delete("0[E2]"), "", "", SIGSTAR)
             @ pynini.cdrewrite(delete("0[E3]"), "[E6]", "", SIGSTAR)
             @ pynini.cdrewrite(delete("0[E6]"), "", "", SIGSTAR)
             @ pynini.cdrewrite(delete("0"), "", "", SIGSTAR)).optimize()

# Inserts an arbitrary number of zeros at the beginning of a string so that
# shorter strings can match in length to RAW_FACTORIZER above.
PAD_ZEROS = insert("0").closure() + pynini.closure(D)

# Changes E1 to E1* for 11-19. See the LEXICON below for how these get
# lexicalized.
FIX_TEENS = pynini.cdrewrite(pynini.cross("[E1]", "[E1*]"), "1", D, SIGSTAR)

# The full factorizer.
F = (PAD_ZEROS @ RAW_FACTORIZER @ DEL_ZEROS @ FIX_TEENS).optimize()

LEXICON = [("1", "one"), ("2", "two"), ("3", "three"), ("4", "four"),
           ("5", "five"), ("6", "six"), ("7", "seven"), ("8", "eight"),
           ("9", "nine"), ("1[E1]", "ten"), ("1[E1*]1", "eleven"),
           ("1[E1*]2", "twelve"), ("1[E1*]3", "thirteen"),
           ("1[E1*]4", "fourteen"), ("1[E1*]5", "fifteen"),
           ("1[E1*]6", "sixteen"), ("1[E1*]7", "seventeen"),
           ("1[E1*]8", "eighteen"), ("1[E1*]9", "nineteen"),
           ("2[E1]", "twenty"), ("3[E1]", "thirty"), ("4[E1]", "forty"),
           ("5[E1]", "fifty"), ("6[E1]", "sixty"), ("7[E1]", "seventy"),
           ("8[E1]", "eighty"), ("9[E1]", "ninety"), ("[E2]", "hundred"),
           ("[E3]", "thousand"), ("[E6]", "million")]

LFST = pynini.string_map(LEXICON).optimize()

# Computes lexicon* with spaces in between words
V = (LFST + (insert(" ") + LFST).closure()).optimize()

# The number name reading transducer.
VERBALIZE = (F @ V).optimize()

