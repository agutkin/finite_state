# Lint as: python3
# For general information on the Pynini grammar compilation library, see
# pynini.opengrm.org.
"""Grammar for generating simple weather expressions given tabular input.

Generation is in two modes, one with normal digit representation of numbers, and
the second with the numbers verbalized.
"""

from typing import Dict, Tuple

import pynini
from pynini.examples import numbers
from pynini.lib import byte

SIGMA = pynini.closure(byte.BYTES).optimize()

SPACE = pynini.accep(" ")

# Singular/plural morphology.
PLURALS = [("degree", "degrees"),
           ("kilometer", "kilometers")]

PUNC = pynini.union("*", ",", ":", "?", "!").optimize()

SINGULARIZATION = pynini.union(*(pynini.cross(o, i) for (i, o) in PLURALS))

SINGULARIZE = pynini.cdrewrite(SINGULARIZATION, ("[BOS]" | SPACE) + "1" + SPACE,
                               SPACE | "[EOS]" | PUNC, SIGMA)

VERBALIZE = pynini.cdrewrite(numbers.VERBALIZE, "[BOS]" | SPACE,
                             SPACE | "[EOS]" | PUNC, SIGMA)


class WeatherTable:
  """Simple object for holding a set of weather data.

  The table is indexed by city and for each city there is data on temperature,
  wind speed, wind direction, current state of the weather (raining, snowing,
  clear, partly cloudy...)
  """

  def __init__(self) -> None:
    self._table: Dict[str, Tuple[int, int, str, str]] = {}
    self._template = (
        "In __CITY__, the current temperature is __TEMPERATURE__ degrees, "
        "the wind is out of the __WIND_DIRECTION__ at __WIND_SPEED__ "
        "kilometers per hour, and it is __STATE__.")

  def _find_city(self, city: str) -> Dict[str, str]:
    """Finds data for a city.

    Args:
      city: a city str.

    Returns:
      A dictionary.
    """
    data = self._table[city]
    return {
        "temperature": str(data[0]),
        "wind_speed": str(data[1]),
        "wind_direction": str(data[2]),
        "state": str(data[3]),
    }

  def add_city(self, city: str, temperature: int, wind_speed: int,
               wind_direction: str, state: str) -> None:
    self._table[city] = (temperature, wind_speed, wind_direction, state)

  @staticmethod
  def sigma_pad(*args: pynini.FstLike) -> pynini.Fst:
    """Helper function that pads a series of arguments with SIGMA.

    Args:
      args: strings or FSTs.

    Returns:
      SIGMA + args0 + SIGMA ... + argsN + SIGMA
    """
    val = SIGMA
    for a in args:
      val += a + SIGMA
    return val.optimize()

  def generate_report(self, city: str) -> str:
    """Generates weather report for the given city.

    Args:
      city: a city string.

    Returns:
      Weather report for the city.
    """
    data = self._find_city(city)
    populate = WeatherTable.sigma_pad(
        pynini.cross("__CITY__", city),
        pynini.cross("__TEMPERATURE__", data["temperature"]),
        pynini.cross("__WIND_DIRECTION__", data["wind_direction"]),
        pynini.cross("__WIND_SPEED__", data["wind_speed"]),
        pynini.cross("__STATE__", data["state"]))
    return (self._template @ populate @ SINGULARIZE).string()

  def verbalize_report(self, city: str) -> str:
    """Generates weather report for the given city, verbalizing the numbers.

    Args:
      city: a city string.

    Returns:
      Weather report for the city, with the numbers verbalized.
    """
    return (self.generate_report(city) @ VERBALIZE).string()

