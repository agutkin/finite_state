# Lint as: python3
# For general information on the Pynini grammar compilation library, see
# pynini.opengrm.org.
"""Grammar to handle the "channel" part of source-channel chatspeak normalizer.

We consider the following cases

1) Common chatspeak terms, from a lexicon.
2) Common patterns, as described by regular expression.
3) Letter-duplication cases, such as "cooooooool"
4) Some abbreviations with optional sonorant and vowel deletions.

Chatspeak terms are normalized by this grammar to a lattice of possible
verbalizations for a sentence, which then gets scored by a language model.

For simplicity we assume that all text is case-free (lower case).
"""

import string

import pynini
from pynini.lib import byte

SIGSTAR = pynini.closure(byte.BYTES).optimize()


def deduplicate(letter: str) -> pynini.Fst:
  """Optionally deletes multiple letters after 1 or 2 of the same letter.

  Args:
    letter: a letter.

  Returns:
    An FST deleting that in an appropriate sequence.
  """
  not_letter = byte.LOWER - letter
  letter = pynini.accep(letter)
  return pynini.cdrewrite(
      pynini.cross(pynini.closure(letter, 1), letter.ques),
      ("[BOS]" | not_letter) + letter, ("[EOS]" | not_letter), SIGSTAR)


class Deduplicator:
  """Container for a deduplicator for all letters."""

  def __init__(self):
    it = iter(string.ascii_lowercase)
    self._fst = deduplicate(next(it))
    for char in it:
      self._fst @= deduplicate(char)
      self._fst.optimize()

  def deduplicate(self, word: pynini.FstLike,
                  dictionary: pynini.Fst) -> pynini.Fst:
    """Finds deduplication candidates for a word in a dictionary.

    Args:
      word: a cooooool-like word.
      dictionary: an FST representing a set of words.

    Returns:
      An FST representing a lattice of possible matches.
    """
    return (word @ self._fst @ dictionary).optimize()


class Lexicon:
  """Container for a lexicon."""

  def __init__(self, path: str):
    self._lexicon = pynini.string_file(path)

  def expand(self, s: pynini.FstLike) -> pynini.Fst:
    return (s @ self._lexicon).optimize()


def plus(letter: str) -> pynini.Fst:
  return pynini.closure(letter, 1)


def star(letter: str) -> pynini.Fst:
  return pynini.closure(letter)


def ques(letter: str) -> pynini.Fst:
  return pynini.closure(letter, 0, 1)


# TODO(rws): The following regexps are based on an internal, now defunct,
# chatspeak project. I need to make sure that it is OK to release these.

SPECIAL_REGEXPS = pynini.union(
    pynini.cross("b" + plus("b") + star("z"), "bye bye"),
    pynini.cross("congrat" + star("z"), "congratulations"),
    pynini.cross("cool" + plus("z"), "cool"),
    pynini.cross("delis" + plus("h"), "delicious"),
    pynini.cross("e" + plus("r"), "uh"), pynini.cross("f" + plus("f"), "ff"),
    pynini.cross("g" + plus("l"), "good luck"),
    pynini.cross("he" + plus("y") + "z", "hey"),
    pynini.cross("he" + ques("'") + plus("z"), "he's"),
    pynini.cross("how" + ques("'") + plus("z"), "how is"),
    pynini.cross("how" + ques("'") + plus("z"), "how has"),
    pynini.cross("how" + ques("'") + plus("z"), "how was"),
    pynini.cross("how" + ques("'") + plus("z"), "how does"),
    pynini.cross("kew" + plus("l") + star("z"), "cool"),
    pynini.cross("k" + plus("k"), "ok"),
    pynini.cross("ko" + plus("o") + "l", "cool"),
    pynini.cross("k" + plus("z"), "ok"),
    pynini.cross(
        plus("l") + pynini.union("o", "u").closure(1) + plus("l") + plus("z"),
        pynini.union("laugh out loud", "laugh")),
    pynini.cross(plus("l") + plus("u") + plus("r") + plus("v"), "love"),
    pynini.cross(
        plus("l") + plus("u") + plus("v") + plus("e") + plus("e"), "love"),
    pynini.cross("mis" + plus("h"), "miss"),
    pynini.cross("m" + plus("m") + "k", "mm ok"),
    pynini.cross("n00b" + plus("z"), "newbie"),
    pynini.cross("na" + plus("h"), "no"),
    pynini.cross("no" + plus("e") + plus("z"), "no"),
    pynini.cross("noob" + plus("z"), "newbie"),
    pynini.cross("oke" + plus("e"), "okay"),
    pynini.cross("oki" + plus("e"), "okay"),
    pynini.cross("ok" + plus("z"), "okay"),
    pynini.cross("om" + plus("g"), "oh my god"),
    pynini.cross("omg" + plus("z"), "oh my god"),
    pynini.cross("orly" + plus("z"), "oh really"),
    pynini.cross("pl" + plus("z"), "please"),
    pynini.cross("pw" + plus("e") + "ase", "please"),
    pynini.cross("q" + plus("n"), "question"),
    pynini.cross("qool" + plus("z"), "cool"),
    pynini.cross("rox0r" + plus("z"), "rocks"),
    pynini.cross("sorry" + plus("z"), "sorry"),
    pynini.cross("s" + plus("o") + "w" + plus("w") + plus("y"), "sorry"),
    pynini.cross("sry" + plus("z"), "sorry"),
    pynini.cross("thanke" + plus("w"), "thank you"),
    pynini.cross("thank" + plus("q"), "thank you"),
    pynini.cross("t" + plus("q"), "thank you"),
    pynini.cross("t" + plus("y"), "thank you"),
    pynini.cross("tyv" + plus("m"), "thank you very much"),
    pynini.cross(plus("u"), "you"), pynini.cross("ug" + plus("h"), "ugh"),
    pynini.cross("u" + plus("h"), "uh"), pynini.cross("wai" + plus("t"),
                                                      "wait"),
    pynini.cross("w" + plus("a") + plus("z"), "what's"),
    pynini.cross("w" + plus("a") + plus("z") + plus("a"), "what's up"),
    pynini.cross(plus("wa") + plus("z") + plus("u") + plus("p"), "what's up"),
    pynini.cross("wh" + plus("a"), "what"),
    pynini.cross("w" + plus("u") + plus("t"), "what"),
    pynini.cross(plus("xo"), "'hugs and kisses'"),
    pynini.cross("ya" + plus("h"), "yeah"),
    pynini.cross("ya" + plus("r"), "yeah"),
    pynini.cross("ye" + plus("a"), "yeah"),
    pynini.cross("yes" + plus("h"),
                 "yes"), pynini.cross("ye" + plus("z"), "yes"),
    pynini.cross("yup" + plus("s"), "yup"),
    pynini.cross("yup" + plus("z"), "yup"),
    pynini.cross("zom" + plus("g"), "oh my god"),
    pynini.cross("z" + plus("u") + plus("p"), "what's up")).optimize()


# Simple vowel/sonorant deletion rule.
V = pynini.union("a", "e", "i", "o", "u")
R = pynini.union("r", "l", "n")
C = byte.LOWER - V
# We must delete a whole vowel span, which may include "y" at the end.
VOWEL_SPAN = V.closure(1) + ques("y")

R_DELETION = pynini.cdrewrite(
    pynini.cross(R, ""), V, C - R, SIGSTAR, mode="opt")
V_DELETION = pynini.cdrewrite(
    pynini.cross(VOWEL_SPAN, ""), C, C | "[EOS]", SIGSTAR, mode="opt")

# Three or more letters
THREE_LETTERS = pynini.closure(byte.LOWER, 3)


class Deabbreviator:
  """Optional sonorant or vowel deletions.

  The result must have at least two letters and should not already be in the
  lexicon (don't expand things that could be words), and the expansion should
  have at least three letters.
  """

  def __init__(self, lexicon: pynini.Fst):
    """lexicon is an FSA representing a lexicon."""
    self._lexicon = lexicon
    self._two_letters_not_in_lexicon = pynini.closure(byte.LOWER, 2) - lexicon
    self._two_letters_not_in_lexicon.optimize()
    self._abbrev_words = (self._two_letters_not_in_lexicon @
                          (self._lexicon @
                           THREE_LETTERS @
                           R_DELETION @
                           V_DELETION).invert()).optimize()

  def expand(self, s: pynini.FstLike) -> pynini.Fst:
    return (s @ self._abbrev_words).optimize()

