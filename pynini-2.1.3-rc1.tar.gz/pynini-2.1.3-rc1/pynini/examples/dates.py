# Lint as: python3
# For general information on the Pynini grammar compilation library, see
# pynini.opengrm.org.
"""Grammar for extracting possible dates from running test (en_us).

Recognizes dates and maps them to a simple XML-markup.
"""

import string

import pynini
from pynini.lib import byte
from pynini.lib import pynutil


def possibly_zero_padded(top: int) -> pynini.Fst:
  """Adds optional leading "0" to single-digit numbers in a range.

  Args:
    top: Top of the range

  Returns:
    An FST representing numbers from 1 to top inclusive, with single digit cases
    possibly with a leading "0".
  """
  nums = [str(d) for d in range(1, top + 1)]
  nums = [f"{d:02d}" for d in range(1, top + 1)] + nums
  return pynini.union(*nums).optimize()


lowercase = pynini.union(
    *[pynini.cross(x.upper(), x) for x in string.ascii_lowercase]).closure()
sigma = pynini.closure(byte.BYTES)
tolower = pynini.cdrewrite(lowercase, "", "", sigma)

month_map = [
    ["1", ["january", "jan", "jan."]],
    ["2", ["february", "feb", "feb."]],
    ["3", ["march", "mar", "mar."]],
    ["4", ["april", "apr", "apr."]],
    ["5", ["may"]],
    ["6", ["june", "jun", "jun."]],
    ["7", ["july", "jul", "jul."]],
    ["8", ["august", "aug", "aug."]],
    ["9", ["september", "sept", "sept.", "sep", "sep."]],
    ["10", ["october", "oct", "oct."]],
    ["11", ["november", "nov", "nov."]],
    ["12", ["december", "dec", "dec."]],
]

month_names = pynini.union(*(pynini.cross(pynini.union(*x[1]), x[0])
                             for x in month_map)).optimize()
month_nums = pynini.union(*(m[0] for m in month_map)).optimize()

space = pynini.accep(" ").closure(1)

# TODO(rws): Make these match for months.
day_nums = possibly_zero_padded(31)

four_etc = pynini.union("4", "5", "6", "7", "8", "9", "0")

day_ordinal = (
    (day_nums @ (sigma + "1")) + pynutil.delete("st") |
    (day_nums @ (sigma + "2")) + pynutil.delete("nd") |
    (day_nums @ (sigma + "3")) + pynutil.delete("rd") |
    (day_nums @ (sigma + four_etc)) + pynutil.delete("th")).optimize()

digit = [str(d) for d in range(10)]
digit_no_zero = [str(d) for d in range(1, 10)]
# Negative weight on year favors picking a longer span including a
# year rather than just month and day, if a possible year is present.
year = (
    pynini.union(*digit_no_zero) + pynini.union(*digit)**3 +
    pynini.accep("", -1))
year.optimize()


def markup(expr: pynini.FstLike, mark: str) -> pynini.Fst:
  """Introduces XML markup.

  Args:
    expr: an FST.
    mark: the name to apply to the region.

  Returns:
    An FST mapping from "expr" to "<mark>expr</mark>".
  """
  return (pynutil.insert("<" + mark + ">") + expr +
          pynutil.insert("</" + mark + ">")).optimize()


mdy_full_date = (
    markup(month_names, "month") + pynutil.delete(space) +
    markup(day_nums, "day") +
    (pynutil.delete(",").ques + pynutil.delete(space) +
     markup(year, "year")).ques)
mdy_full_date_ordinal = (
    markup(month_names, "month") + pynutil.delete(space) +
    pynutil.delete("the" + space).ques + markup(day_ordinal, "day") +
    (pynutil.delete(",").ques + pynutil.delete(space) +
     markup(year, "year")).ques)
dmy_full_date = (
    markup(day_nums, "day") + pynutil.delete(space) +
    markup(month_names, "month") +
    (pynutil.delete(",").ques + pynutil.delete(space) +
     markup(year, "year")).ques)
dmy_full_date_ordinal = (
    pynutil.delete("the" + space).ques + markup(day_ordinal, "day") +
    pynutil.delete(space) + pynutil.delete("of" + space) +
    markup(month_names, "month") +
    (pynutil.delete(",").ques + pynutil.delete(space) +
     markup(year, "year")).ques)
numeric_ymd = (
    markup(year, "year") + pynutil.delete("/") + markup(month_nums, "month") +
    pynutil.delete("/") + markup(day_nums, "day"))
numeric_dmy = (
    markup(day_nums, "day") + pynutil.delete("/") +
    markup(month_nums, "month") + pynutil.delete("/") + markup(year, "year"))
month_year = (
    markup(month_names, "month") + pynutil.delete(space) + markup(year, "year"))
date = (
    mdy_full_date | mdy_full_date_ordinal | dmy_full_date
    | dmy_full_date_ordinal | numeric_ymd | numeric_dmy | month_year)
date = markup(date, "date")

DATE_TRANSDUCER = (tolower @ date).optimize()

DATE_MATCHER = pynini.cdrewrite(DATE_TRANSDUCER, "", "", sigma).optimize()

