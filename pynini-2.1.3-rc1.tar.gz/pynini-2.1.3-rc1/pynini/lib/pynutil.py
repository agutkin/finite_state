# Lint as: python3
# For general information on the Pynini grammar compilation library, see
# pynini.opengrm.org.
"""Simple utility functions.

Please do not add overly-specific functions or introduce additional
dependencies (i.e., beyond Pynini itself) to this module.
"""

from typing import Optional

import pynini


def add_weight(expr: pynini.FstLike,
               weight: pynini.WeightLike) -> pynini.Fst:
  """Attaches a weight to an automaton.

  Args:
    expr: an acceptor or string.
    weight: a weight or string.

  Returns:
    An FST.
  """
  return pynini.accep("", weight=weight).concat(expr)


def insert(expr: pynini.FstLike,
           weight: Optional[pynini.WeightLike] = None) -> pynini.Fst:
  """Creates the transducer for <epsilon> x expr.

  Args:
    expr: an acceptor or string.
    weight: an optional weight or string.

  Returns:
    An FST.
  """
  result = pynini.cross("", expr)
  if weight is not None:
    return add_weight(result, weight)
  else:
    return result


def delete(expr: pynini.FstLike,
           weight: Optional[pynini.WeightLike] = None) -> pynini.Fst:
  """Creates the transducer for expr x <epsilon>.

  Args:
    expr: an acceptor or string.
    weight: an optional weight or string.

  Returns:
    An FST.
  """
  result = pynini.cross(expr, "")
  if weight is not None:
    return add_weight(result, weight)
  else:
    return result


def join(expr: pynini.FstLike, sep: pynini.FstLike) -> pynini.Fst:
  """Creates the automaton expr (sep expr)^*.

  Args:
    expr: an acceptor or string.
    sep: a separator acceptor or string.

  Returns:
    An FST.
  """
  cdr = pynini.concat(sep, expr).closure()
  return expr + cdr

