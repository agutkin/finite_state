# Lint as: python3
# For general information on the Pynini grammar compilation library, see
# pynini.opengrm.org.
"""Tests for the chatspeak model."""

import os
from typing import List

from absl import flags

import pynini
from pynini.examples import chatspeak
from pynini.lib import rewrite
import unittest

FLAGS = flags.FLAGS


class ChatspeakTest(unittest.TestCase):

  deduplicator: chatspeak.Deduplicator
  deabbreviator: chatspeak.Deabbreviator
  regexps: chatspeak.Regexps
  lexicon: chatspeak.Lexicon

  @classmethod
  def setUpClass(cls):
    super().setUpClass()
    lexicon = pynini.union("the", "cool", "warthog", "escaped", "easily",
                           "from", "baltimore", "zoo", "col")
    cls.deduplicator = chatspeak.Deduplicator(lexicon)
    cls.deabbreviator = chatspeak.Deabbreviator(lexicon)
    cls.regexps = chatspeak.Regexps()
    cls.lexicon = chatspeak.Lexicon(
        os.path.join(
            FLAGS.test_srcdir, "google3/nlp/grm/language/pynini/examples/"
            "testdata/chatspeak_lexicon.tsv"))

  def testDeduplicator(self):

    def expand_string(s: str) -> List[str]:
      return rewrite.lattice_to_strings(self.deduplicator.expand(s))

    self.assertCountEqual(expand_string("cooooool"), ["cool", "col"])
    self.assertCountEqual(
        expand_string("coooooooooooooooollllllllll"), ["cool", "col"])
    self.assertCountEqual(expand_string("chicken"), [])

  def testDeabbreviator(self):

    def expand_string(s: str) -> List[str]:
      return rewrite.lattice_to_strings(self.deabbreviator.expand(s))

    self.assertCountEqual(expand_string("wrthg"), ["warthog"])
    self.assertCountEqual(expand_string("wthg"), ["warthog"])
    self.assertCountEqual(expand_string("z"), [])

  def testRegexps(self):

    def expand_string(s: str) -> List[str]:
      return rewrite.lattice_to_strings(self.regexps.expand(s))

    result = expand_string("delish")
    self.assertCountEqual(result, ["delicious"])
    result = expand_string("kooooooooool")
    self.assertCountEqual(result, ["cool"])
    result = expand_string("zomgggggggg")
    self.assertCountEqual(result, ["oh my god"])

  def testLexicon(self):

    def expand_string(s: str) -> List[str]:
      return rewrite.lattice_to_strings(self.lexicon.expand(s))

    self.assertCountEqual(expand_string("1nam"), ["one in a million"])


if __name__ == "__main__":
  unittest.main()

