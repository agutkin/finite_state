# Lint as: python3
# For general information on the Pynini grammar compilation library, see
# pynini.opengrm.org.
"""Tests for the chatspeak model."""

import os
from typing import List

from absl import flags

import pynini
from pynini.examples import chatspeak
import unittest

FLAGS = flags.FLAGS


class ChatspeakTest(unittest.TestCase):

  lexicon: pynini.Fst
  deduplicator: chatspeak.Deduplicator
  chat_lexicon: chatspeak.Lexicon
  deabbreviator: chatspeak.Deabbreviator

  @classmethod
  def setUpClass(cls):
    super().setUpClass()
    cls.lexicon = pynini.union("the", "cool", "warthog", "escaped", "easily",
                               "from", "baltimore", "zoo", "col")
    cls.deduplicator = chatspeak.Deduplicator()
    cls.chat_lexicon = chatspeak.Lexicon(
        os.path.join(
            FLAGS.test_srcdir, "google3/nlp/grm/language/pynini/examples/"
            "testdata/chatspeak_lexicon.tsv"))
    cls.deabbreviator = chatspeak.Deabbreviator(cls.lexicon)

  def testCooooooool(self):
    result = list(
        self.deduplicator.deduplicate("cooooool",
                                      self.lexicon).paths().ostrings())
    self.assertCountEqual(result, ["cool", "col"])
    result = list(
        self.deduplicator.deduplicate("coooooooooooooooollllllllll",
                                      self.lexicon).paths().ostrings())
    self.assertCountEqual(result, ["cool", "col"])
    result = list(
        self.deduplicator.deduplicate("chicken",
                                      self.lexicon).paths().ostrings())
    self.assertCountEqual(result, [])

  def testLexicon(self):
    result = list(self.chat_lexicon.expand("1nam").paths().ostrings())
    self.assertCountEqual(result, ["one in a million"])

  def testRegexps(self):

    def expand_string(s: str) -> List[str]:
      lattice = s @ chatspeak.SPECIAL_REGEXPS
      return list(lattice.paths().ostrings())

    result = expand_string("delish")
    self.assertCountEqual(result, ["delicious"])
    result = expand_string("kooooooooool")
    self.assertCountEqual(result, ["cool"])
    result = expand_string("zomgggggggg")
    self.assertCountEqual(result, ["oh my god"])

  def testAbbreviations(self):

    def expand_string(s: str) -> List[str]:
      return list(self.deabbreviator.expand(s).paths().ostrings())

    result = expand_string("wrthg")
    self.assertCountEqual(result, ["warthog"])
    result = expand_string("wthg")
    self.assertCountEqual(result, ["warthog"])
    result = expand_string("z")
    self.assertCountEqual(result, [])


if __name__ == "__main__":
  unittest.main()

