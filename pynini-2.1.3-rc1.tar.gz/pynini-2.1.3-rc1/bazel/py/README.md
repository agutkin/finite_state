Configuration files for Python interoperability development libraries required
for building with Cython.

Copied from [gRPC Core](https://github.com/grpc/grpc/tree/master/third_party/py).
